from pathlib import Path

def part5_check(base):
    if not (base / 'data' / 'imaging').is_dir():
        print('[-] Part 5: imaging folder not moved!')
        return False
    if not (base / 'data' / 'imaging' / 'ft_timer.tif').is_file():
        print('[-] Part 5: contents of imaging folder not moved!')
        return False
    
    return True

def part6_check(base):
    try:
        with open(base / 'README.txt', 'r') as f:
            lines = f.read().split('\n')
            if lines[1] == '':
                print('[-] Part 6: Name not added to README')
                return False
    except:
        return False
    return True

def part7_check(base):
    if not (base / 'data' / 'flow').is_dir():
        print('[-] Part 7: flow directory not created')
        return False
    
    if not (base / 'data' / 'sequencing').is_dir():
        print('[-] Part 7: sequencing directory is not present!')
        return False

    if not (base / 'data' / 'imaging').is_dir():
        print('[-] Part 7: imaging directory is not present!')
        return False

    for child in (base / 'data' / 'sequencing').iterdir():
        if child.suffix != '.fastq':
            print('[-] Part 7: non-FASTQ files present in the sequencing directory!')
            return False

    for child in (base / 'data' / 'imaging').iterdir():
        if child.suffix != '.tif':
            print('[-] Part 7: non-TIF files present in the imaging directory!')
            return False

    for child in (base / 'data' / 'flow').iterdir():
        if child.suffix != '.fcs':
            print('[-] Part 7: non-FCS files present in the flow directory!')
            return False

    if (base / 'data' / 'mixed').is_dir():
        print('[-] Part 7: Mixed directory not deleted')
        return False
    return True

def part8_check(base):
    for year in ['2019', '2020', '2021']:
        if not (base / 'data' / 'raw' / year).is_dir():
            print('[-] Part 8: Year directories not created!')
            return False

    if (not (base / 'data' / 'raw' / '2019' / '2019.08.06_SlowFT_reprogram').is_dir() or
        not (base / 'data' / 'raw' / '2019' / '2019.08.06_SlowFT_reprogram' / '20x_CH1 2.tif').is_file()):
        print('[-] Part 8: Not all folders in raw directory copied properly!')
        return False

    if not (base / 'data' / 'raw' / '2021' / '2021.01.05_15dpi_Experiment_Group_dsRED_ASO_p53-2.fcs').is_file():
        print('[-] Part 8: Not all files copied correctly to raw directory')
        return False
    return True

if __name__ == '__main__':
    base_path = Path(__file__).parent.absolute()
    result = True
    result = result & part5_check(base_path)
    result = result & part6_check(base_path)
    result = result & part7_check(base_path)
    result = result & part8_check(base_path)

    if not result:
        print('Checks failed')
    else:
        print('All checks passed! :)')

